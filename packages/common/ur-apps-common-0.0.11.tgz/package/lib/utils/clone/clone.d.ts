export declare function cloneObject<T extends Record<string, any>>(obj: T, clonedMap?: WeakMap<object, any>): T;
export declare function cloneArray<T extends Array<unknown>>(arr: T, clonedMap?: WeakMap<object, any>): T;
export declare function cloneSet<T extends Set<unknown>>(value: T, clonedMap?: WeakMap<object, any>): T;
export declare function cloneMap<T extends Map<unknown, unknown>>(value: T, clonedMap?: WeakMap<object, any>): T;
export declare function cloneDate<T extends Date>(value: T): T;
export declare function clone<T>(value: T, clonedMap?: WeakMap<object, any>): T;
