import { AnyFn } from '../../types';
import { DebouncedFn, DebounceOptions } from './types';
/**
 * Creates a debounced version of the provided function.
 *
 * @param fn The function to debounce.
 * @param wait The number of milliseconds to wait before invoking the function.
 * @param options Options for controlling the debounce behavior.
 * @returns A debounced version of the original function.
 */
export declare function debounce<F extends AnyFn>(fn: F, wait: number, options?: DebounceOptions): DebouncedFn<F>;
