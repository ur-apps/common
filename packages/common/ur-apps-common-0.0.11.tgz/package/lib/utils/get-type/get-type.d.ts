/**
 * Types of values that can be returned by the getType function.
 */
export type TValueType = 'string' | 'number' | 'bigint' | 'boolean' | 'symbol' | 'null' | 'undefined' | 'object' | 'array' | 'date' | 'function';
/**
 * Determines the type of the given value.
 * @param value - The value whose type needs to be determined.
 * @returns The type of the value.
 */
export declare function getType(value: unknown): TValueType;
/**
 * Checks if the value is a string.
 * @param value - The value to check.
 * @returns true if the value is a string, otherwise false.
 */
export declare function isString(value: unknown): value is string;
/**
 * Checks if the value is a number.
 * @param value - The value to check.
 * @returns true if the value is a number, otherwise false.
 */
export declare function isNumber(value: unknown): value is number;
/**
 * Checks if the value is a bigint.
 * @param value - The value to check.
 * @returns true if the value is a bigint, otherwise false.
 */
export declare function isBigInt(value: unknown): value is bigint;
/**
 * Checks if the value is a boolean.
 * @param value - The value to check.
 * @returns true if the value is a boolean, otherwise false.
 */
export declare function isBoolean(value: unknown): value is boolean;
/**
 * Checks if the value is a symbol.
 * @param value - The value to check.
 * @returns true if the value is a symbol, otherwise false.
 */
export declare function isSymbol(value: unknown): value is symbol;
/**
 * Checks if the value is a date.
 * @param value - The value to check.
 * @returns true if the value is a date, otherwise false.
 */
export declare function isDate(value: unknown): value is Date;
/**
 * Checks if the value is an array.
 * @param value - The value to check.
 * @returns true if the value is an array, otherwise false.
 */
export declare function isArray<T>(value: unknown): value is Array<T>;
/**
 * Checks if the value is an object.
 * @param value - The value to check.
 * @returns true if the value is an object, otherwise false.
 */
export declare function isObject(value: unknown): value is object;
/**
 * Checks if the value is null.
 * @param value - The value to check.
 * @returns true if the value is null, otherwise false.
 */
export declare function isNull(value: unknown): value is null;
/**
 * Checks if the value is undefined.
 * @param value - The value to check.
 * @returns true if the value is undefined, otherwise false.
 */
export declare function isUndefined(value: unknown): value is undefined;
/**
 * Checks if the value is null or undefined.
 * @param value - The value to check.
 * @returns true if the value is null or undefined, otherwise false.
 */
export declare function isNullish(value: unknown): value is null | undefined;
/**
 * Checks if the value is of an allowed type.
 * @param value - The value to check.
 * @param allowed - An array of allowed types.
 * @returns true if the value is of an allowed type, otherwise false.
 */
export declare function isAllowedType(value: unknown, allowed: TValueType[]): boolean;
