import { AnyFn } from '../../types';
import { ThrottledFn, ThrottleOptions } from './types';
/**
 * Creates a throttled function that only invokes func at most once per every wait milliseconds.
 * The throttled function comes with a cancel method to cancel delayed func invocations
 * and a flush method to immediately invoke them.
 *
 * This implementation uses debounce with maxWait to achieve throttling behavior.
 */
export declare function throttle<F extends AnyFn>(fn: F, wait: number, options?: ThrottleOptions): ThrottledFn<F>;
